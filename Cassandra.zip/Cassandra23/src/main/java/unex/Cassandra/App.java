package unex.Cassandra;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        
        //Ejemplo 1
        SimpleClient client1 = new SimpleClient();
        client1.connect("127.0.0.1");
        client1.close();
        
        //Ejemplo 2
        SecondClient client2 = new SecondClient();
        client2.connect("127.0.0.1");
        client2.createSchema();
        client2.loadData();
        client2.querySchema();
        client2.close();
    }
}
