mapreduce-basico
================

Primeros pasos de MapReduce con Hadoop

http://www.adictosaltrabajo.com/tutoriales/tutoriales.php?pagina=mapreduce_basic
